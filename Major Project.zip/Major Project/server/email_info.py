EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_USE_TLS= True
EMAIL_HOST = 'sandbox.smtp.mailtrap.io'
EMAIL_HOST_USER='e7f68662371b8e'
EMAIL_HOST_PASSWORD='6774da84fc6fbd'
EMAIL_PORT=2525